./ore-miner  mine --address GfkEuLdiX3KYeAjRn8hknQDMWobjkBezhwzWWywigMCK --threads 30 --invcode 888888

