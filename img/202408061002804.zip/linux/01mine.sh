./ore-miner  mine --address BW4arkQ9WwZd8D3qBm722zjyNA3qRe4uWLNF8zyXoxNj --threads 30 --invcode I421D4

