./ore mine --threads 4 --rpc https://solana-api.instantnodes.io/token-5XGJuvElD1pxCQF6yN7sdhOaEtBQqoIV --keypair ./1.json
