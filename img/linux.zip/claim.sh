./ore claim --rpc https://node.onekey.so/sol --keypair ./1.json
