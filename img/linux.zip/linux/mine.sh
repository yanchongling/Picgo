./ore --priority-fee 1000000 mine --threads 12 --rpc https://node.onekey.so/sol --keypair ./1.json
