./ore-miner  mine --address GfkEuLdiX3KYeAjRn8hknQDMWobjkBezhwzWWywigMCK --threads 30 --invcode I421D4

