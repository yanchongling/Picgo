./ore-miner  claim --address GfkEuLdiX3KYeAjRn8hknQDMWobjkBezhwzWWywigMCK  --invcode I421D4

